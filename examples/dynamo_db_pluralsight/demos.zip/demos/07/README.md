# AWS Developer: Getting Started with DynamoDB

## Index

* application-score-trigger-policy.json: IAM Role Policy for Application Score Trigger
* application-score-trigger.js: Lambda function code to calculate application score for each Job Application
* log-stream-events-policy.json: IAM Role Policy to log events to CloudWatch
* log-stream-events.js: Lambda function code to log events from Stream to CloudWatch