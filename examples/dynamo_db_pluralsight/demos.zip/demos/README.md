# Pluralsight Course: AWS Developer - Getting Started with DynamoDB
## Support exercises / demos

**Author:** Abhaya Chauhan [[Blog](https://www.abhayachauhan.com)] [[Twitter](https://twitter.com/AbhayaChauhan)]

Please `npm install` before running any scripts.

Each directory indicates the module for which it supports.

Any questions, please get in touch.
